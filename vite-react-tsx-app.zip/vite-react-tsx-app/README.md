# Vite + React + TSX

Dự án mã nguồn mở (open source), khởi tạo với **Vite**, **React** và **TypeScript (TSX)**, sẵn sàng để chạy local, tự host hoặc deploy lên **Vercel**.

## 🧱 Công nghệ sử dụng

- [Vite](https://vite.dev) — build tool siêu nhanh
- [React 18](https://react.dev) — thư viện UI
- [TypeScript](https://www.typescriptlang.org) — kiểu tĩnh cho JS/TSX
- [Vercel](https://vercel.com) — nền tảng deploy (tùy chọn)

## 📦 Cài đặt

Yêu cầu: [Node.js](https://nodejs.org) >= 18.

```bash
# Cài dependencies
npm install
```

## 🚀 Chạy local (development)

```bash
npm run dev
```

Mặc định chạy tại `http://localhost:5173`.

## 🏗️ Build production

```bash
npm run build
```

Kết quả build nằm trong thư mục `dist/`.

## 👀 Xem thử bản build

```bash
npm run preview
```

## ☁️ Deploy lên Vercel

Dự án đã có sẵn file `vercel.json` cấu hình build/output.

### Cách 1: Dùng Vercel CLI

```bash
npm install -g vercel
vercel login
vercel
```

Làm theo hướng dẫn trên terminal. Lần deploy đầu, Vercel sẽ hỏi cấu hình — cứ để mặc định vì `vercel.json` đã khai báo sẵn framework là `vite`.

Để deploy bản production:

```bash
vercel --prod
```

### Cách 2: Deploy qua GitHub (khuyến nghị cho dự án mã nguồn mở)

1. Đẩy (push) dự án này lên một repository GitHub:

   ```bash
   git init
   git add .
   git commit -m "Initial commit: Vite + React + TSX"
   git branch -M main
   git remote add origin https://github.com/<tên-người-dùng>/<tên-repo>.git
   git push -u origin main
   ```

2. Vào [vercel.com/new](https://vercel.com/new), đăng nhập bằng GitHub.
3. Chọn **Import** repository vừa tạo.
4. Vercel sẽ tự nhận diện framework là **Vite** (nhờ `vercel.json`), giữ nguyên cấu hình mặc định:
   - Build Command: `npm run build`
   - Output Directory: `dist`
   - Install Command: `npm install`
5. Bấm **Deploy**.

Sau đó mỗi lần bạn push code mới lên nhánh `main`, Vercel sẽ tự động build & deploy lại (CI/CD liên tục).

## 🗂️ Cấu trúc thư mục

```
vite-react-tsx-app/
├── public/              # Tài nguyên tĩnh
│   └── vite.svg
├── src/
│   ├── App.tsx          # Component chính
│   ├── App.css
│   ├── main.tsx         # Entry point
│   └── index.css
├── index.html
├── package.json
├── vite.config.ts
├── tsconfig.json
├── vercel.json          # Cấu hình deploy Vercel
├── .gitignore
├── LICENSE               # Giấy phép MIT
└── README.md
```

## 📄 Giấy phép

Dự án này được phát hành theo giấy phép **MIT** — xem chi tiết trong file [LICENSE](./LICENSE). Bạn được tự do sử dụng, sao chép, chỉnh sửa và phân phối lại mã nguồn.

## 🤝 Đóng góp

Đây là một dự án mã nguồn mở, mọi đóng góp (pull request, báo lỗi, đề xuất tính năng) đều được hoan nghênh.
