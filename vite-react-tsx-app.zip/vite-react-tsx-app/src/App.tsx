import { useState } from 'react'
import './App.css'
import Calculator from './tools/Calculator'
import UnitConverter from './tools/UnitConverter'
import CurrencyConverter from './tools/CurrencyConverter'

type ToolKey = 'calculator' | 'unit' | 'currency'

const TOOLS: { key: ToolKey; label: string; icon: string }[] = [
  { key: 'calculator', label: 'Máy tính', icon: '🧮' },
  { key: 'unit', label: 'Đổi đơn vị', icon: '📏' },
  { key: 'currency', label: 'Đổi tiền tệ', icon: '💱' },
]

function App() {
  const [active, setActive] = useState<ToolKey>('calculator')

  return (
    <div className="app">
      <header className="hero">
        <h1>
          <span className="accent">ToolBox</span>
        </h1>
        <p className="subtitle">Bộ công cụ tiện ích — mã nguồn mở</p>
      </header>

      <nav className="tab-nav">
        {TOOLS.map((t) => (
          <button
            key={t.key}
            className={'tab-btn' + (active === t.key ? ' tab-btn-active' : '')}
            onClick={() => setActive(t.key)}
          >
            <span className="tab-icon">{t.icon}</span>
            {t.label}
          </button>
        ))}
      </nav>

      <main className="card">
        {active === 'calculator' && <Calculator />}
        {active === 'unit' && <UnitConverter />}
        {active === 'currency' && <CurrencyConverter />}
      </main>

      <footer className="footer">
        <p>MIT License · Được xây dựng với Vite ⚡</p>
      </footer>
    </div>
  )
}

export default App
