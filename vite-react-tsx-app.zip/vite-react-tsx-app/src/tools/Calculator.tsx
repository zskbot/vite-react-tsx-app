import { useState } from 'react'

function calculate(a: number, b: number, op: string): number {
  switch (op) {
    case '+':
      return a + b
    case '-':
      return a - b
    case '×':
      return a * b
    case '÷':
      return b === 0 ? NaN : a / b
    default:
      return b
  }
}

export default function Calculator() {
  const [display, setDisplay] = useState('0')
  const [stored, setStored] = useState<number | null>(null)
  const [operator, setOperator] = useState<string | null>(null)
  const [waitingForOperand, setWaitingForOperand] = useState(false)

  const inputDigit = (digit: string) => {
    if (waitingForOperand) {
      setDisplay(digit)
      setWaitingForOperand(false)
    } else {
      setDisplay(display === '0' ? digit : display + digit)
    }
  }

  const inputDot = () => {
    if (waitingForOperand) {
      setDisplay('0.')
      setWaitingForOperand(false)
      return
    }
    if (!display.includes('.')) setDisplay(display + '.')
  }

  const clearAll = () => {
    setDisplay('0')
    setStored(null)
    setOperator(null)
    setWaitingForOperand(false)
  }

  const toggleSign = () => {
    setDisplay(display.startsWith('-') ? display.slice(1) : '-' + display)
  }

  const inputPercent = () => {
    setDisplay(String(parseFloat(display) / 100))
  }

  const performOperator = (nextOperator: string) => {
    const inputValue = parseFloat(display)

    if (stored === null) {
      setStored(inputValue)
    } else if (operator) {
      const result = calculate(stored, inputValue, operator)
      setDisplay(String(result))
      setStored(result)
    }

    setWaitingForOperand(true)
    setOperator(nextOperator)
  }

  const handleEquals = () => {
    const inputValue = parseFloat(display)
    if (operator && stored !== null) {
      const result = calculate(stored, inputValue, operator)
      setDisplay(String(result))
      setStored(null)
      setOperator(null)
      setWaitingForOperand(true)
    }
  }

  const buttons = [
    ['C', '±', '%', '÷'],
    ['7', '8', '9', '×'],
    ['4', '5', '6', '-'],
    ['1', '2', '3', '+'],
    ['0', '.', '='],
  ]

  const handlePress = (label: string) => {
    if (/[0-9]/.test(label)) return inputDigit(label)
    if (label === '.') return inputDot()
    if (label === 'C') return clearAll()
    if (label === '±') return toggleSign()
    if (label === '%') return inputPercent()
    if (label === '=') return handleEquals()
    return performOperator(label)
  }

  return (
    <div className="tool calculator">
      <div className="calc-display">{display}</div>
      <div className="calc-grid">
        {buttons.flat().map((label) => (
          <button
            key={label}
            className={[
              'calc-btn',
              label === '=' ? 'calc-btn-wide calc-btn-accent' : '',
              ['÷', '×', '-', '+'].includes(label) ? 'calc-btn-accent' : '',
              ['C', '±', '%'].includes(label) ? 'calc-btn-muted' : '',
              operator === label && !waitingForOperand ? 'calc-btn-active' : '',
            ]
              .filter(Boolean)
              .join(' ')}
            onClick={() => handlePress(label)}
          >
            {label}
          </button>
        ))}
      </div>
    </div>
  )
}
