import { useMemo, useState } from 'react'

// Tỷ giá mẫu (quy về 1 USD). Đây KHÔNG phải tỷ giá thời gian thực.
// Có thể thay thế bằng dữ liệu từ một API tỷ giá thật (ví dụ exchangerate.host,
// open.er-api.com...) bằng cách fetch và cập nhật RATES lúc runtime.
const RATES: Record<string, number> = {
  USD: 1,
  VND: 25450,
  EUR: 0.92,
  GBP: 0.79,
  JPY: 149.5,
  KRW: 1330,
  CNY: 7.1,
  AUD: 1.51,
  SGD: 1.34,
}

const LABELS: Record<string, string> = {
  USD: 'Đô la Mỹ (USD)',
  VND: 'Đồng Việt Nam (VND)',
  EUR: 'Euro (EUR)',
  GBP: 'Bảng Anh (GBP)',
  JPY: 'Yên Nhật (JPY)',
  KRW: 'Won Hàn Quốc (KRW)',
  CNY: 'Nhân dân tệ (CNY)',
  AUD: 'Đô la Úc (AUD)',
  SGD: 'Đô la Singapore (SGD)',
}

export default function CurrencyConverter() {
  const codes = Object.keys(RATES)
  const [from, setFrom] = useState('USD')
  const [to, setTo] = useState('VND')
  const [input, setInput] = useState('1')

  const result = useMemo(() => {
    const value = parseFloat(input)
    if (isNaN(value)) return ''
    const usd = value / RATES[from]
    const converted = usd * RATES[to]
    return converted.toLocaleString('vi-VN', {
      maximumFractionDigits: 4,
    })
  }, [input, from, to])

  const swap = () => {
    setFrom(to)
    setTo(from)
  }

  return (
    <div className="tool converter">
      <p className="tool-note">
        ⚠️ Tỷ giá bên dưới là dữ liệu mẫu cố định, chỉ mang tính minh họa —
        không phải tỷ giá thời gian thực.
      </p>

      <div className="converter-row">
        <div className="converter-field">
          <input
            type="number"
            value={input}
            onChange={(e) => setInput(e.target.value)}
          />
          <select value={from} onChange={(e) => setFrom(e.target.value)}>
            {codes.map((c) => (
              <option key={c} value={c}>
                {LABELS[c]}
              </option>
            ))}
          </select>
        </div>

        <button className="swap-btn" onClick={swap} aria-label="Đổi chiều">
          ⇄
        </button>

        <div className="converter-field">
          <input type="text" value={result} readOnly />
          <select value={to} onChange={(e) => setTo(e.target.value)}>
            {codes.map((c) => (
              <option key={c} value={c}>
                {LABELS[c]}
              </option>
            ))}
          </select>
        </div>
      </div>
    </div>
  )
}
