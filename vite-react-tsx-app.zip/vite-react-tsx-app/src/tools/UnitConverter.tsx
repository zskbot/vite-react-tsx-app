import { useMemo, useState } from 'react'

type UnitCategory = {
  name: string
  units: Record<string, number> // hệ số quy đổi về đơn vị gốc
}

const CATEGORIES: Record<string, UnitCategory> = {
  length: {
    name: 'Độ dài',
    units: {
      'Milimét (mm)': 0.001,
      'Xentimét (cm)': 0.01,
      'Mét (m)': 1,
      'Kilômét (km)': 1000,
      'Inch (in)': 0.0254,
      'Feet (ft)': 0.3048,
      'Dặm (mi)': 1609.34,
    },
  },
  weight: {
    name: 'Cân nặng',
    units: {
      'Miligam (mg)': 0.001,
      'Gam (g)': 1,
      'Kilôgam (kg)': 1000,
      'Tấn (t)': 1_000_000,
      'Pound (lb)': 453.592,
      'Ounce (oz)': 28.3495,
    },
  },
  temperature: {
    name: 'Nhiệt độ',
    units: { Celsius: 0, Fahrenheit: 1, Kelvin: 2 }, // xử lý riêng
  },
  volume: {
    name: 'Thể tích',
    units: {
      'Mililít (ml)': 0.001,
      'Lít (l)': 1,
      'Mét khối (m³)': 1000,
      'Gallon (gal, US)': 3.78541,
    },
  },
}

function convertTemperature(value: number, from: string, to: string): number {
  // Quy về Celsius trước
  let celsius: number
  if (from === 'Celsius') celsius = value
  else if (from === 'Fahrenheit') celsius = ((value - 32) * 5) / 9
  else celsius = value - 273.15 // Kelvin

  if (to === 'Celsius') return celsius
  if (to === 'Fahrenheit') return (celsius * 9) / 5 + 32
  return celsius + 273.15 // Kelvin
}

export default function UnitConverter() {
  const [category, setCategory] = useState<keyof typeof CATEGORIES>('length')
  const cat = CATEGORIES[category]
  const unitNames = Object.keys(cat.units)

  const [fromUnit, setFromUnit] = useState(unitNames[0])
  const [toUnit, setToUnit] = useState(unitNames[1] ?? unitNames[0])
  const [input, setInput] = useState('1')

  const handleCategoryChange = (key: keyof typeof CATEGORIES) => {
    setCategory(key)
    const names = Object.keys(CATEGORIES[key].units)
    setFromUnit(names[0])
    setToUnit(names[1] ?? names[0])
  }

  const result = useMemo(() => {
    const value = parseFloat(input)
    if (isNaN(value)) return ''

    if (category === 'temperature') {
      return roundSmart(convertTemperature(value, fromUnit, toUnit))
    }

    const fromFactor = cat.units[fromUnit]
    const toFactor = cat.units[toUnit]
    const base = value * fromFactor
    return roundSmart(base / toFactor)
  }, [input, fromUnit, toUnit, category, cat.units])

  return (
    <div className="tool converter">
      <div className="converter-tabs">
        {Object.entries(CATEGORIES).map(([key, c]) => (
          <button
            key={key}
            className={
              'chip' + (category === key ? ' chip-active' : '')
            }
            onClick={() => handleCategoryChange(key as keyof typeof CATEGORIES)}
          >
            {c.name}
          </button>
        ))}
      </div>

      <div className="converter-row">
        <div className="converter-field">
          <input
            type="number"
            value={input}
            onChange={(e) => setInput(e.target.value)}
          />
          <select value={fromUnit} onChange={(e) => setFromUnit(e.target.value)}>
            {unitNames.map((u) => (
              <option key={u} value={u}>
                {u}
              </option>
            ))}
          </select>
        </div>

        <div className="converter-equals">=</div>

        <div className="converter-field">
          <input type="text" value={result} readOnly />
          <select value={toUnit} onChange={(e) => setToUnit(e.target.value)}>
            {unitNames.map((u) => (
              <option key={u} value={u}>
                {u}
              </option>
            ))}
          </select>
        </div>
      </div>
    </div>
  )
}

function roundSmart(n: number): string {
  if (!isFinite(n)) return ''
  const rounded = Math.round(n * 1e6) / 1e6
  return String(rounded)
}
